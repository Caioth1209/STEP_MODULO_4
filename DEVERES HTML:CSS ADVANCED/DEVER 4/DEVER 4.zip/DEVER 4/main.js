function mexeQuem(){

    document.getElementById("quem").style.boxShadow = '1px 1px 20px white';

    setTimeout(() => {

        document.getElementById("quem").style.boxShadow = '1px 1px 5px white';
        
    }, 400);
    
}

function mexeQuais(){

    document.getElementById("quais").style.boxShadow = '1px 1px 20px white';

    setTimeout(() => {

        document.getElementById("quais").style.boxShadow = '1px 1px 5px white';
        
    }, 400);

}

function mexeOnde(){

    document.getElementById("onde").style.boxShadow = '1px 1px 20px white';

    setTimeout(() => {

        document.getElementById("onde").style.boxShadow = '1px 1px 5px white';
        
    }, 400);

}