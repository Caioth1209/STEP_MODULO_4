window.onload = ()=>{
    sessionStorage.clear();
}