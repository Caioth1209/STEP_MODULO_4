setTimeout(() => {
    imprimePessoasSemTel();
}, 1500);