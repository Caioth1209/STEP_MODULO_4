setTimeout(() => {
    imprimePessoasMaioresIdade();
}, 1500);