setTimeout(() => {
    imprimePessoasMenoresIdade();
}, 1500);